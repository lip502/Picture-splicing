clc;
close all;
I0=imread('001.bmp');
[m,n]=size(I0);
for Frame=0
    c=num2str(Frame,'%03d');
    c=strcat(c,'.bmp');
    I=double(imread(c));
    figure(1);
    imshow(I);
    T=MaxVarianceThreshold(I);
    BW=ImageBW(I,T);
    figure(2);
    imshow(BW);
    k=1;
    for i=1:m
        s(k)=0;
        for j=1:n
            s(k)=s(k)+BW(i,j)/255;
        end
        k=k+1;
    end
end
       figure(3);
    plot(s);


