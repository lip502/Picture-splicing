function I=ImageBW(I,threshold);
A=find(I>threshold);
B=find(I<=threshold);
I(A)=255;
I(B)=0;