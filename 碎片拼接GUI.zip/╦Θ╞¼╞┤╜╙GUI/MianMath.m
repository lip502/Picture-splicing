function varargout = MianMath(varargin)
% MIANMATH M-file for MianMath.fig
%      MIANMATH, by itself, creates a new MIANMATH or raises the existing
%      singleton*.
%
%      H = MIANMATH returns the handle to a new MIANMATH or the handle to
%      the existing singleton*.
%
%      MIANMATH('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MIANMATH.M with the given input arguments.
%
%      MIANMATH('Property','Value',...) creates a new MIANMATH or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MianMath_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MianMath_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MianMath

% Last Modified by GUIDE v2.5 22-Aug-2021 21:58:37

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
'gui_Singleton',  gui_Singleton, ...
'gui_OpeningFcn', @MianMath_OpeningFcn, ...
'gui_OutputFcn',  @MianMath_OutputFcn, ...
'gui_LayoutFcn',  [] , ...
'gui_Callback',   []);
if nargin && ischar(varargin{1})
gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
[varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MianMath is made visible.
function MianMath_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MianMath (see VARARGIN)

% Choose default command line output for MianMath
handles.output = hObject;
set(gcf,'name','��ϵQ��115195686 '); 
str1=sprintf('����˼·\n\n');
str4=sprintf('           ����ʱ��ִ٣������������ϵ��ʦQ��115195686 \n');
string=[str1 str4];
msgbox(string,'��ܰ��ʾ','none');
return
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MianMath wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = MianMath_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function File_Callback(hObject, eventdata, handles)
% hObject    handle to File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% --------------------------------------------------------------------
function OpenImage_Callback(hObject, eventdata, handles)
% hObject    handle to OpenImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,pathname]=uigetfile({'*.bmp';'*.jpg'},'����ͼ��');
if isequal(filename,0)|isequal(pathname,0)
    errordlg('��û��ѡ��Ҫ�򿪵��ļ�','������Ϣ��ʾ��');
    return;
else
    file=[pathname,filename];
    axes(handles.axes1);
    figure=imread(file);
    imshow(figure);
end
%handles.img=file;
%guidata(hObject,handles);
% --------------------------------------------------------------------




% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
